from django.apps import AppConfig


class FinalprojappConfig(AppConfig):
    name = 'finalprojapp'
